package compiler.syntax.nonTerminal;


/**
 * Abstract Class for Axiom non terminal.
 */
public abstract class Axiom
    extends NonTerminal
{
    /**
     * Constructor for Axiom.
     */
    public Axiom ()
    {
        super (); 
    }
}
